# RAMkiller

##DO NOT RUN WITHOUT READING THIS

This program is similar to Matrix.bat with a few exceptions... it kills your computer.

Runs Matrix.bat but will open itself up constantly preventing manual shutdown of the program and eventual use of all RAM on the computer
<br>Dropped my school comp in a minute >:D (School computers are pretty bad)

###You'll need to right-click the file and press edit before you can use it. There is further explanation in the program.
<br>You can also make it work faster, more explanation in the program.

Can be used for trolling others or when you're bored, don't credit me though. Only thing I don't want credit for.

